module.exports = {
	framework: false,
	deploy: 'wp'
}
